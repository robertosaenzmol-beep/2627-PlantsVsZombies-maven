package tp1.pvz.logic.gameobjects;

import tp1.pvz.logic.GameWorld;
import tp1.pvz.utils.Position;
import tp1.pvz.view.Messages;

public class Peashooter extends GameObject {
    public static final int COST = 50;
    public static final int DAMAGE = 1;
    public static final int ENDURANCE = 3;

    private int health;

    public Peashooter(Position pos, GameWorld game) {
        super(game, pos);
        this.health = ENDURANCE;
    }

    @Override
    public void onEnter() {
    }

    @Override
    public void update() {
        game.attackZombieInRow(position, DAMAGE);
    }

    @Override
    public void onExit() {
    }

    public void receiveDamage(int damage) {
        health -= damage;
    }

    @Override
    public boolean isAlive() {
        return health > 0;
    }

    @Override
    public String getIcon() {
        return String.format(Messages.PEASHOOTER_ICON, this.health);
    }

    @Override
    public String getDescription() {
        return String.format(Messages.PEASHOOTER_DESCRIPTION, COST, DAMAGE, ENDURANCE);
    }
}
